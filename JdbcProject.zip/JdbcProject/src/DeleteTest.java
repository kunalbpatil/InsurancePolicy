import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteTest {
	public static void main(String[] args) {
		
		try {
			//1. load the driver...
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Loaded the driver.....");
			
			System.out.println("Trying to connect to the DB...");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:"
					+ "@localhost:1521:xe",
					"system", "sysgitc");
			System.out.println("connected to the db...."+conn);
			
			System.out.println("Trying to create PreparedStatement...");
			PreparedStatement pst = conn.prepareStatement("delete from emp where empno = ?");
			System.out.println("PreparedStatement created : "+pst);
			
			System.out.println("Trying to execute statement...");
			Scanner scan1 = new Scanner(System.in);
			Scanner scan2 = new Scanner(System.in);
			Scanner scan3 = new Scanner(System.in);
			Scanner scan4 = new Scanner(System.in);
			Scanner scan5 = new Scanner(System.in);
			Scanner scan6 = new Scanner(System.in);
			Scanner scan7 = new Scanner(System.in);
			Scanner scan8 = new Scanner(System.in);
			
			System.out.println("Enter emp number of employee to be deleted : " );
			int empNumber = scan1.nextInt();
			
			Statement st = conn.createStatement();
			ResultSet resultSet = st.executeQuery("select empno from emp where empno = '"+empNumber+"'");
			if(!resultSet.next()) {
				throw new EmployeeNotFoundException("Employee with EMPNO "+empNumber+" does not exists..");
			}
			
			
			pst.setInt(1, empNumber );
			
			int rowsDeleted = pst.executeUpdate();
			
			System.out.println("Statement executed : rows deleted : "+rowsDeleted);
			pst.close();			conn.close();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}