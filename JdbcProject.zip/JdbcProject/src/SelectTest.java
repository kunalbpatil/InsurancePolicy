import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectTest {

	public static void main(String[] args) {
		try {
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Loaded the driver...");
			
			System.out.println("Trying to connect to the db...");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","sysgitc");
			System.out.println("Connected to the DB..."+conn);
			
			System.out.println("Trying to create statement...");
			Statement statement = conn.createStatement();
			System.out.println("Statement created: "+statement);
			
			System.out.println("Trying to execute the statement...");
			ResultSet resultset = statement.executeQuery("select * from dept");
			System.out.println("Statement executed : got the result : "+resultset);
			while(resultset.next()) {
				int deptNo = resultset.getInt(1);
				String deptName = resultset.getString(2);
				String locName = resultset.getString(3);
				System.out.println("DEPTNO: "+deptNo);
				System.out.println("DEPTNAME: "+deptName);
				System.out.println("LOCATION: "+locName);
				System.out.println("---------------------------------------------");
			}
			
			resultset.close();
			statement.close();
			conn.close();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
