import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class SelectWhereDate {

	public static void main(String[] args) {
		try {
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Loaded the driver...");
			
			System.out.println("Trying to connect to the db...");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","sysgitc");
			System.out.println("Connected to the DB..."+conn);
			
			System.out.println("Trying to create statement...");
			Statement statement = conn.createStatement();
			System.out.println("Statement created: "+statement);
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter start date of employee: ");
			String sdate = sc.next();
			System.out.println("Enter end date of employee: ");
			String edate = sc.next();
			ResultSet resultset = statement.executeQuery("select * from emp where hiredate between '"+ sdate +"' and '"+edate+"'");
			System.out.println("Statement executed : got the result : "+statement);
			
					
			while(resultset.next()) {
				System.out.println("row: "+resultset.getRow());
				int empNo = resultset.getInt(1);
				String empName = resultset.getString(2);
				String locName = resultset.getString(3);
				System.out.println("EMPNO: "+empNo);
				System.out.println("EMPNAME: "+empName);
				System.out.println("LOCATION: "+locName);
				System.out.println("---------------------------------------------");
			}
			
			
			resultset.close();
			statement.close();
			conn.close();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Something went wrong... "+e);
		}
	}

}
