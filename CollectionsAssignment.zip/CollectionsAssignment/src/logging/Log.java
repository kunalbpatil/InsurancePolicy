package logging;

import java.time.LocalDate;

public class Log {
	private String logMsg,logType,logLevel;
	private LocalDate logDateTime;
	public Log(String logMsg, String logType, String logLevel, LocalDate logDateTime) {
		super();
		this.logMsg = logMsg;
		this.logType = logType;
		this.logLevel = logLevel;
		this.logDateTime = logDateTime;
	}
	public String getLogMsg() {
		return logMsg;
	}
	public void setLogMsg(String logMsg) {
		this.logMsg = logMsg;
	}
	public String getLogType() {
		return logType;
	}
	public void setLogType(String logType) {
		this.logType = logType;
	}
	public String getLogLevel() {
		return logLevel;
	}
	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}
	public LocalDate getLogDateTime() {
		return logDateTime;
	}
	public void setLogDateTime(LocalDate logDateTime) {
		this.logDateTime = logDateTime;
	}
	@Override
	public String toString() {
		return "Log [logMsg=" + logMsg + ", logType=" + logType + ", logLevel=" + logLevel + ", logDateTime="
				+ logDateTime + "]";
	}
	
	
	
	
}
