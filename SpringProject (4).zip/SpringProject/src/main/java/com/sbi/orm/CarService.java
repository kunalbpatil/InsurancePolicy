package com.sbi.orm;

import java.util.List;

import org.springframework.stereotype.Service;
@Service
public interface CarService {
	public void saveCar(Car car);
	public void modifyCar(Car car);
	public void deleteCar(int carId);
	public Car selectCar(int carId);
	public List<Car> selectAllCars();
}
