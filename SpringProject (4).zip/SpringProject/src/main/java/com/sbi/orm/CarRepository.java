package com.sbi.orm;

import java.util.List;

import org.springframework.stereotype.Repository;
@Repository
public interface CarRepository {
	public void insertCar(Car car);
	public void updateCar(Car car);
	public void deleteCar(int carId);
	public Car selectCar(int carId);
	public List<Car> selectAllCars();
}
