import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.orm.Car;
import com.sbi.orm.CarRepository;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = { "classpath:SpringORM.xml" })
public class SpringORMTest {
	@Autowired
	CarRepository carRepo;
	@Autowired
	Car car;

	@Test
	public void insertCarTest() {

		car.setCarId(20);
		car.setCarName("BMW");
		carRepo.insertCar(car);
	}

	@Test
	public void updateCarTest() {
		car.setCarName("BMW");
		car.setCarId(10);
		carRepo.updateCar(car);
	}

	@Test
	public void deleteCarTest() {

		carRepo.deleteCar(10);
	}

	@Test
	public void selectCarTest() {

		Car car = carRepo.selectCar(10);
		if (car != null) {
			System.out.println("Car Id	: " + car.getCarId());
			System.out.println("Car Name: " + car.getCarName());
		}
	}

	@Test
	public void selectAllCarTest() {

		List<Car> carList = carRepo.selectAllCars();
		if (carList != null) {
			for (Car car : carList) {
				System.out.println("Car Id	: " + car.getCarId());
				System.out.println("Car Name: " + car.getCarName());
				System.out.println("-------------------------------------");
			}
		}
	}
}
