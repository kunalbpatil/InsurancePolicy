package mypackage;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ord")
public class Order {
	@Id
	private Integer ordId;
	private LocalDate orderDate,shipDate;
	private String commPlan;
	private Integer custId;
	private Double total;
	public Integer getOrderId() {
		return ordId;
	}
	public void setOrderId(Integer orderId) {
		this.ordId = orderId;
	}
	public LocalDate getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	public LocalDate getShipDate() {
		return shipDate;
	}
	public void setShipDate(LocalDate shipDate) {
		this.shipDate = shipDate;
	}
	public String getCommPlan() {
		return commPlan;
	}
	public void setCommPlan(String commPlan) {
		this.commPlan = commPlan;
	}
	public Integer getCustId() {
		return custId;
	}
	public void setCustId(Integer custId) {
		this.custId = custId;
	}
	public Double getTotal() {
		return total;
	}
	public void setTotal(Double total) {
		this.total = total;
	}
	
	
}
