package mypackage;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class BaseDAOImpl implements BaseDAO {
	EntityManagerFactory emf;

	public BaseDAOImpl() {
		emf = Persistence.createEntityManagerFactory("MyJPA");

	}

	public void persist(Object obj) {
		EntityManager em = emf.createEntityManager();
		try {

			em.getTransaction().begin();
			em.persist(obj);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			em.close();
		}

	}

	public void merge(Object obj) {
		// TODO Auto-generated method stub
		EntityManager em = emf.createEntityManager();
		try {

			em.getTransaction().begin();
			em.merge(obj);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			em.close();
		}
	}

	public void remove(Object obj) {
		// TODO Auto-generated method stub
		EntityManager em = emf.createEntityManager();
		try {

			em.getTransaction().begin();
			em.remove(obj);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			em.close();
		}
	}

	public <AnyType> AnyType find(Class<AnyType> className, Serializable primaryKey) {
		EntityManager em = emf.createEntityManager();
		AnyType obj =  em.find(className, primaryKey);
		return obj;
	}

	public <AnyType> List<AnyType> findAll(String entityName) {
		EntityManager em = emf.createEntityManager();
		Query query =  em.createQuery("from "+entityName);
		List<AnyType> objList = query.getResultList();
		//System.out.println("List: "+objList);
		return objList;
	}

}
