package mypackage;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Item {
	@Id
	private Integer ordId;
	private Integer itemId,prodId,qty;
	private Double actualPrice,itemTot;
	public Integer getOrdId() {
		return ordId;
	}
	public void setOrdId(Integer ordId) {
		this.ordId = ordId;
	}
	public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	public Integer getProdId() {
		return prodId;
	}
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}
	public Integer getQty() {
		return qty;
	}
	public void setQty(Integer qty) {
		this.qty = qty;
	}
	public Double getActualPrice() {
		return actualPrice;
	}
	public void setActualPrice(Double actualPrice) {
		this.actualPrice = actualPrice;
	}
	public Double getItemTot() {
		return itemTot;
	}
	public void setItemTot(Double itemTot) {
		this.itemTot = itemTot;
	}
	
}
