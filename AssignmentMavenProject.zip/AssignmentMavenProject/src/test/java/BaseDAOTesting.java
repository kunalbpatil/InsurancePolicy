import java.util.List;

import org.junit.jupiter.api.Test;

import mypackage.BaseDAOImpl;
import mypackage.Customer;
import mypackage.Employee;
import mypackage.Item;
import mypackage.Order;
import mypackage.Price;
import mypackage.Product;

public class BaseDAOTesting {
	@Test
	public void assignment() {
		BaseDAOImpl baseDAO  = new BaseDAOImpl();
		Employee emp;
		System.out.println("Finding MARTIN");
		List<Employee> empList = baseDAO.findAll("Employee where ename = 'MARTIN'");
		if(!empList.isEmpty()) {
			emp = empList.get(0);
		
		
		System.out.println("Printing Customers of MARITN");
		
		List<Customer> custList = baseDAO.findAll("Customer where REPID = '"+emp.getEmpNo()+"'");
		for(Customer cust: custList) {
			System.out.println("CustID	:"+cust.getCustId());
			System.out.println("CustName	:"+cust.getName());
			System.out.println("-------Orders of "+cust.getName()+" ------------------");
			
			List<Order> orderList = baseDAO.findAll("Order where CUSTID = '"+cust.getCustId()+"'");
			for(Order ord: orderList) {
				System.out.println("OrderId		:"+ord.getOrderId());
				System.out.println("OrderDate	:"+ord.getOrderDate());
				System.out.println("ShipDate	:"+ord.getShipDate());
				System.out.println("Total		:"+ord.getTotal());
				System.out.println("------------------------- Items of order "+ ord.getOrderId()+"-----------------------------");
				List<Item> itemList = baseDAO.findAll("Item where ORDID = '"+ord.getOrderId()+"'");
				for(Item item:itemList) {
					System.out.println("ItemId		:"+item.getItemId());
					System.out.println("ProductId	:"+item.getProdId());
					System.out.println("ActualPrice	:"+item.getActualPrice());
					System.out.println("Qty			:"+item.getQty());
					System.out.println("ItemTotal	:"+item.getItemTot());
					
					System.out.println("-----------------------Product Description of product "+item.getProdId()+"---------------------");
					
					Product prd = baseDAO.find(Product.class, item.getProdId());
					
					System.out.println("Prod Description: "+prd.getDescrip());
					
					List<Price> priceList = baseDAO.findAll("Price where PRODID = '"+prd.getProdId()+"' order by STARTDATE desc ");
					System.out.println("----------------------------------------------------------------------------------");
					System.out.println("STDPRICE of product "+ prd.getProdId()+" : "+priceList.get(0).getStdPrice());
					System.out.println("----------------------------------------------------------------------------------");
				}
				
				
				System.out.println("-----------------------------------------------------------------");
			}
		}
		
		}
		
		
	}
}
