package vehicle;

public abstract class AirVehicle implements  Vehicle{
	public abstract void fly();
}
