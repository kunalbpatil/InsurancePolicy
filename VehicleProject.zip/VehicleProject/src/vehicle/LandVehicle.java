package vehicle;

public abstract class LandVehicle implements Vehicle{
	public abstract void drive();
}
