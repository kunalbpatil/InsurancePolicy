package vehicle;

public class Boat extends SeaVehicle {

	@Override
	public void transport() {
		// TODO Auto-generated method stub

	}

	@Override
	public void sail() {
		// TODO Auto-generated method stub

	}

}
