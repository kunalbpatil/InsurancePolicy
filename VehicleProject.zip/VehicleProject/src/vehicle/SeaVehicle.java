package vehicle;

public abstract class SeaVehicle implements Vehicle{
	public abstract void sail();
}
