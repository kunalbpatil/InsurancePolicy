package vehicle;

public class Bike extends LandVehicle {

	@Override
	public void transport() {
		// TODO Auto-generated method stub

	}

	@Override
	public void drive() {
		// TODO Auto-generated method stub

	}

}
