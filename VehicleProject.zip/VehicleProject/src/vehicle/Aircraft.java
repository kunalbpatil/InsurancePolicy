package vehicle;

public class Aircraft extends AirVehicle {

	@Override
	public void transport() {
		// TODO Auto-generated method stub

	}

	@Override
	public void fly() {
		// TODO Auto-generated method stub

	}

}
