package vehicle;

/**
 * Vehicle interface to put mandate on child implementation classes.
 *
 */
public interface Vehicle {
	
	/**
	 * Transport is the action of carrying or taking people or goods from one place to another
	 * 
	 */
	public void transport();
}
