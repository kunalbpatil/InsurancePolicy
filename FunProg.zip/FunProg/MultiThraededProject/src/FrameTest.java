import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JTextField;

public class FrameTest {
	public static void main(String[] args) {
		MyFrame mf1 = new MyFrame(300, 200, 100, 100, "My Car");
		MyFrame mf2 = new MyFrame(300, 200, 400, 100, "My Plane");
		MyFrame mf3 = new MyFrame(300, 200, 700, 100, "My Bike");

		Thread t1 = new Thread(mf1);
		Thread t2 = new Thread(mf2);
		Thread t3 = new Thread(mf3);
		
		t1.start();
		t2.start();
		t3.start();
	}
}

class MyFrame extends JFrame implements Runnable {
	JTextField ta = new JTextField(20);
	String title;

	MyFrame(int w, int h, int x, int y, String title) {
		super.setSize(w, h);
		super.setLocation(x, y);
		this.title = title;
		super.setTitle(title);
		super.setVisible(true);
		super.setLayout(new FlowLayout());
		super.add(ta);
		super.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public void run() {
		for (int i = 1; i <= 1000000; i++) {
			ta.setText(title + "is running " + i);
		}

	}
	
}
