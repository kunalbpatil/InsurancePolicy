public class ThreadTest {
	public static void main(String[] args) {
		
		Thread myCar = new Car();
		Train train = new Train();
		Ship ship = new Ship();
		Flight flight = new Flight();
		Bike bike = new Bike();
		Chalk ch1 = new Chalk("White");
		Chalk ch2= new Chalk("Green");
		Chalk ch3= new Chalk("Blue");
		
		Thread t1 = new Thread(ch1);
		Thread t2 = new Thread(ch2);
		Thread t3 = new Thread(ch3);
		
		t1.start();
		t2.start();
		t3.start();
		
		myCar.start();
		train.start();
		ship.start();
		flight.start();
		bike.start();
		
	}
}

class Car extends Thread //1
{
	public void run() { //2
		for (int i = 1; i <= 250; i++) {
			System.out.println("Car is running....."+i);
		}
	}
}
class Train extends Thread //1
{
	public void run() { //2
		for (int i = 1; i <= 550; i++) {
			System.out.println("\tTrain is running....."+i);
		}
	}
}

class Ship extends Thread //1
{
	public void run() { //2
		for (int i = 1; i <= 750; i++) {
			System.out.println("\t\tShip is sailing....."+i);
		}
	}
}
class Bike extends Thread //1
{
	public void run() { //2
		for (int i = 1; i <= 550; i++) {
			System.out.println("\tBike is running....."+i);
		}
	}
}


class Flight extends Thread //1
{
	public void run() { //2
		for (int i = 1; i <= 1000; i++) {
			System.out.println("\t\t\tFlight is flying....."+i);
		}
	}
}
class Stone{
	
}

class Chalk extends Stone implements Runnable {
	String color;
	public Chalk(String c) {
		color =c;
		
	}
	public void run() {
		for (int i = 1; i <= 1000; i++) {
			System.out.println(color+" Chalk is writing....."+i);
		}
	}
}
	