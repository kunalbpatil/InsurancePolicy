

public class tt {
	public static void main(String[] args) {

		Cinema c = new Cinema();
		c.setCinemaType("Bollywood");
		System.out.println("Type of Cinema is :"+ c);
		
		Movie movie = new Movie(1, "KGF", "Action", "2 Hours", "Hindi,Tamil", "Based on true story");
		
		Theatre theatre = new Theatre();
		theatre.setCinemaType("Bollywood");
		theatre.setTheatreId(1);
		theatre.setTheatreName("PVR");
		theatre.setTheatreCity("Mumbai");
		System.out.println(theatre+ "is a cinema");
		System.out.println("Theatre has: "+movie);
		
		Ticket ticket = theatre.ticket(movie, 1);
		
		System.out.println("");
		System.out.println(ticket);
	}

}
class Cinema{
	String cinemaType;

	public String getCinemaType() {
		return cinemaType;
	}

	public void setCinemaType(String cinemaType) {
		this.cinemaType = cinemaType;
	}

	@Override
	public String toString() {
		return "Cinema [cinemaType=" + cinemaType + "]";
	}
	
}

interface ITheatreService{
	void addTheatre();
	void viewTheatre();
	void deleteTheatre();
}

class Theatre extends Cinema implements ITheatreService{
	private int theatreId;
	private String theatreName;
	private String theatreCity;
	private Movie movie;
	public Ticket ticket(Movie m,int id) {
		Ticket tic = new Ticket();
		int price=0;
		tic.setTicketId(id);
		tic.setMovieName(m.getMovieName());
		if(m.getMovieGenre()== "Action") {
			price = 400;
		}
		if(m.getMovieGenre()== "Thriller") {
			price = 450;
		}
		if(m.getMovieGenre()== "Patriotic") {
			price = 500;
		}
		tic.setTicketPrice(price);
		return tic;
	}
	public int getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(int theatreId) {
		this.theatreId = theatreId;
	}
	public String getTheatreName() {
		return theatreName;
	}
	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}
	public String getTheatreCity() {
		return theatreCity;
	}
	public void setTheatreCity(String theatreCity) {
		this.theatreCity = theatreCity;
	}
	public Movie getMovie() {
		return movie;
	}
	public void setMovie(Movie movie) {
		this.movie = movie;
	}
	@Override
	public String toString() {
		return "Theatre [theatreId=" + theatreId + ", theatreName=" + theatreName + ", theatreCity=" + theatreCity
				+ "]";
	}
	@Override
	public void addTheatre() {
		System.out.println("Thatre is added");
		
	}
	@Override
	public void viewTheatre() {
		System.out.println("These are list of theatre");
		
	}
	@Override
	public void deleteTheatre() {
		System.out.println("Thatre is deleted successfully");
		
	}
	
	
}
class Movie{
	private int movieId;
	private String movieName;
	private String movieGenre;
	private String movieHours;
	private String movieLanguage;
	private String movieDescription;
	public Movie(int movieId, String movieName, String movieGenre, String movieHours, String movieLanguage,
			String movieDescription) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.movieGenre = movieGenre;
		this.movieHours = movieHours;
		this.movieLanguage = movieLanguage;
		this.movieDescription = movieDescription;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getMovieGenre() {
		return movieGenre;
	}
	public void setMovieGenre(String movieGenre) {
		this.movieGenre = movieGenre;
	}
	public String getMovieHours() {
		return movieHours;
	}
	public void setMovieHours(String movieHours) {
		this.movieHours = movieHours;
	}
	public String getMovieLanguage() {
		return movieLanguage;
	}
	public void setMovieLanguage(String movieLanguage) {
		this.movieLanguage = movieLanguage;
	}
	public String getMovieDescription() {
		return movieDescription;
	}
	public void setMovieDescription(String movieDescription) {
		this.movieDescription = movieDescription;
	}
	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", movieGenre=" + movieGenre + ", movieHours="
				+ movieHours + ", movieLanguage=" + movieLanguage + ", movieDescription=" + movieDescription + "]";
	}
	
}

class Ticket{
	private int ticketId;
	private int ticketPrice;
	private String movieName;
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public int getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(int ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	@Override
	public String toString() {
		return "Ticket [ticketId=" + ticketId + ", ticketPrice=" + ticketPrice + ", movieName=" + movieName + "]";
	}
	
	
}