import java.time.LocalDate;

public class Banker {
	public static void main(String[] args) {
		
		Employe e1 = new Employe("SBI", 1, "Abhay");
		Employe e2 = new Employe("SBI", 2, "Vijay");
		Employe e3 = new Employe("SBI", 3, "Raj");
		Employe e4 = new Employe("BOI", 1, "Saad");
		
		System.out.println(e1);
		System.out.println(e2);
		System.out.println(e3);
		System.out.println(e4);
		
		Performance per = new Performance(8, 5);
		
		Salary s = e1.cal(per);
		System.out.println(s);
		
	}
}
class Bank{
	String bankName;

	public Bank(String bankName) {
		super();
		this.bankName = bankName;
	}

	@Override
	public String toString() {
		return "Bank [bankName=" + bankName + "]";
	}
	
}

class Employe extends Bank{
	int empID;
	String empName;
	public Employe(String bankName, int empID, String empName) {
		super(bankName);
		this.empID = empID;
		this.empName = empName;
	}
	@Override
	public String toString() {
		return "Employe [empID=" + empID + ", empName=" + empName + "]";
	}
	Salary cal(Performance p) {
		int sal=3600*p.days*p.hours;
		Salary s = new Salary(sal, LocalDate.now());
		return s;
	}
}

class Salary{
	int sal;
	LocalDate date;
	public Salary(int sal, LocalDate date) {
		super();
		this.sal = sal;
		this.date = date;
	}
	@Override
	public String toString() {
		return "Salary [sal=" + sal + ", date=" + date + "]";
	}
	
}

class Performance{
	int hours;
	int days;
	public Performance(int hours, int days) {
		super();
		this.hours = hours;
		this.days = days;
	}
	@Override
	public String toString() {
		return "Effort [hours=" + hours + ", days=" + days + "]";
	}
	
	
}