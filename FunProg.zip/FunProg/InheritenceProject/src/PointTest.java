
public class PointTest {

	public static void main(String[] args) {
//		GrandFather g = new Child(30);
		Point2D p1 = new Point2D(10,20);
		ColorPoint2D c1 = new ColorPoint2D(10, 20, "red");
		System.out.println(p1);
		System.out.println(c1);
		Point3D p2 = new Point3D(10,20,30);
		ColorPoint3d c2 = new ColorPoint3d(10, 20, 30,"blue");
		System.out.println(p2);
		System.out.println(c2);
	}

}
class Point2D{
	protected int x;
	protected int y;
	public Point2D(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	@Override
	public String toString() {
		return "Point2D [x=" + x + ", y=" + y + "]";
	}
	
}
class ColorPoint2D extends Point2D{
	String colorx;
	public ColorPoint2D(int x, int y, String colorx) {
		super(x, y);
		this.colorx = colorx;
	}
	@Override
	public String toString() {
		return "ColorPoint2D [" + super.toString() + ", colorx=" + colorx + ", ]";
	}
	
	
}
class Point3D extends Point2D{
	protected int z;

	public Point3D(int x, int y, int z) {
		super(x, y);
		this.z = z;
	}

	@Override
	public String toString() {
		return "Point3D [" + "x="+super.x+" , "+"y="+super.y + ", z=" + z + "]";
	}	
}
class ColorPoint3d extends Point3D{
	String colorx;
	public ColorPoint3d(int x, int y, int z, String colorx) {
		super(x, y, z);
		this.colorx = colorx;
	}
	@Override
	public String toString() {
		return "ColorPoint3d ["+ "x="+super.x+" , "+ "y="+ super.y+" , "+"z="+super.z+", colorx=" + colorx + "]";
	}
	
	
}
class GrandFather{
	GrandFather(){
		System.out.println("\t GrandFather constructor......");
	}
	
}
class Father extends GrandFather{
	Father(){
		System.out.println("\t Father constructor......");
	}
}
class Child extends Father{
	Child(int i){
		System.out.println("\t Child constructor......"+i);
	}
}