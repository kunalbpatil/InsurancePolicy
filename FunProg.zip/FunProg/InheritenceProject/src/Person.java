public class Person{
	public static void main(String[] args) {
		PersonDetail p =new PersonDetail('M', 15, "Abhay");
		System.out.println(p);
		Student s = new Student('F', 23, "Ankita", 05, "JNU", "CS");
		System.out.println(s);
		Employee e = new Employee('F', 19, "Nandy", 18, "BSVP", "EC",3 , "SBI", "Manager", 50000);
		System.out.println(e);
	}
}
class PersonDetail {
	char gender;
	int age;
	String name;
	PersonDetail(char gender, int age, String name) {
		super();
		this.gender = gender;
		this.age = age;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Person [gender=" + gender + ", age=" + age + ", name=" + name + "]";
	}

}
class Student extends PersonDetail{
	int rollNo;
	String collegeName;
	String stream;
	public Student(char gender, int age, String name, int rollNo, String collegeName, String stream) {
		super(gender, age, name);
		this.rollNo = rollNo;
		this.collegeName = collegeName;
		this.stream = stream;
	}
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", collegeName=" + collegeName + ", stream=" + stream + "]";
	}
}
class Employee extends Student{
	int empNo;
	String companyName;
	String designation;
	double salary;
	public Employee(char gender, int age, String name, int rollNo, String collegeName, String stream, int empNo,
			String companyName, String designation, double salary) {
		super(gender, age, name, rollNo, collegeName, stream);
		this.empNo = empNo;
		this.companyName = companyName;
		this.designation = designation;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", companyName=" + companyName + ", designation=" + designation
				+ ", salary=" + salary + "]";
	}
	
}