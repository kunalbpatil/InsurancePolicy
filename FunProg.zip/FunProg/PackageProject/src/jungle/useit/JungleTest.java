package jungle.useit;

import jungle.cave.Tiger;
import jungle.cave.WhiteTiger;

public class JungleTest {

	public static void main(String[] args) {
		System.out.println("Begin main...");
		Tiger t = new Tiger();
		t.roar();
		System.out.println("----------------"); //TDD
		WhiteTiger wt = new WhiteTiger();
		wt.roar();
	}
}

/*
  	
 		pack1.pack2.pack3
		ClassName 		- SavingsAccount
		variableName 	- rollNumber
		methodName 		- setLookAndFeel()
		CONSTANT 		- PI
		

*/