
public class FunctionTypes {

	public static void main(String[] args) {
		System.out.println("Hey--");
//		System.out.println();
//		System.out.println("***----Welcome to Calculator---***");
//		Calculator calculate = new Calculator();
//		calculate.add();
//		calculate.subtract();
//		calculate.multiply();
//		calculate.divide();
//		System.out.println();
//		System.out.println();
		System.out.println("***---Welcome to My Theatre---***");
		Theatre theatre = new Theatre();
		theatre.Welcome();
		theatre.addTheatre("PVR","Pune");
		String modify= theatre.modifyTheatre("Cinepolis", "Mumbai");
		  System.out.println(modify);
		int d = theatre.deleteTheatre();
		  System.out.println("Theatre is deleted :"+ d);
		
	}
}
//class Calculator
//{
//	void add() {
//		System.out.println("Adding two number");
//	}
//	void subtract() {
//		System.out.println("Subtracting two number");
//	}
//	void multiply() {
//		System.out.println("Multiplying two number");
//	}
//	void divide() {
//		System.out.println("Dividing two number");
//	}
//}


