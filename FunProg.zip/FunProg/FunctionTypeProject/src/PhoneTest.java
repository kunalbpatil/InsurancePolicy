
public class PhoneTest {

	public static void main(String[] args) {
		Phone ph = new Phone();
		ph.dial();
		byte police = 100;
		ph.dial(police);
		short railwayEnquiryNumber = 139;
		ph.dial(railwayEnquiryNumber);
		byte b =22;
		long n= 123132;
		ph.dial(b, n);
		
		
	}

}

class Phone {
	void dial() {
		System.out.println("Dial() nowhere.......");
	}
	void dial(byte intercom) {
		System.out.println("dial(byte) to......"+intercom);
	}
	void dial(short helpline) {
		System.out.println("dial(byte) to......"+helpline);
	}
	void dial(short code, short number) {
		System.out.println("dial(short,short) to......"+code+","+number);
	}
	void dial(byte code, long number) {
		System.out.println("dial(byte, long) to......"+code+","+number);
	}
}
