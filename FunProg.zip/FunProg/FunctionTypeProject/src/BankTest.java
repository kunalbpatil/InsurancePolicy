import java.time.LocalDate;

public class BankTest {

	public static void main(String[] args) {
		
		System.out.println("Begin Main");
		System.out.println("********");
		
		BankAccount bankObj1 = new BankAccount();
		BankAccount bankObj2 = new BankAccount();
		BankAccount bankObj3 = new BankAccount();
		
		bankObj1.setBankAccount(101, "Jack", 5000.0,2022,11,27);
		bankObj2.setBankAccount(102, "Jane", 10000.0,2013,10,20);
		bankObj3.setBankAccount(103, "Smith", 15000.0,2020,1,25);
		
//		bankObj1.printAccount();
//		bankObj2.printAccount();
//		bankObj3.printAccount();
		
//		bankObj1.withdraw(2500);
//		bankObj1.deposit(1500);
		System.out.println("Intital (Payee) amount of "+bankObj1.accHolder+" is:"+bankObj1.accBalance);
		System.out.println("Intital (Receiver) amount of "+bankObj2.accHolder+" is:"+bankObj2.accBalance);
		System.out.println("-----------------------------");
		
		bankObj1.tranfer(2000,bankObj1,bankObj2);
		bankObj1.printAccount();
		bankObj2.printAccount();
		
		
		System.out.println("Over");
	}
}

class BankAccount {
	int accNumber;
	String accHolder;
	double accBalance;
	LocalDate accOpeningDate;

	public void setBankAccount(int x, String y, double z, int year,int month, int day) {
		accNumber = x;
		accHolder = y;
		accBalance = z;
		accOpeningDate = LocalDate.of(year, month, day);
	}
	public void withdraw(double withdrawAmount) {
		System.out.println(accHolder+ " is Withdrawing Amount: "+ withdrawAmount);
		accBalance = accBalance -withdrawAmount;
		printAccount();
	}
	public void deposit(double depositAmount) {
		System.out.println(accHolder + " is Depositing Amount: "+ depositAmount);
		accBalance = accBalance + depositAmount;
		printAccount();
	}
	public void tranfer(int amount ,BankAccount objPayee, BankAccount objReciever) {
		System.out.println("Money Transfer of Rs:"+amount+" initiated from "+objPayee.accHolder+" account");
		System.out.println("*****");
		System.out.println("Money transfer successful and updated details are:");
		objReciever.accBalance = objReciever.accBalance+ amount;
		objPayee.accBalance=objPayee.accBalance - amount ;
		
	}
	public void printAccount() {
		System.out.println("Account Number  : " + accNumber);
		System.out.println("Account Holder  : " + accHolder);
		System.out.println("Account Balance : " + accBalance);
		System.out.println("Account Opening Date : " + accOpeningDate);

		System.out.println("--------------------------");
	}
}


