import java.io.PrintWriter;

public class DataTypes {
	public static void main(String[] args) {
		
		char aa='\u0905';
		char aa2='\u2665';
		char aa3='\u263A';
		PrintWriter myWriter = new PrintWriter(System.out,true);
		myWriter.println("aa="+aa);
		myWriter.println("aa2="+aa2);
		myWriter.println("aa3="+aa3);
	}
}
