import java.util.InputMismatchException;
import java.util.Scanner;

public class DivisionTest {

	public static void main(String[] args) {
		System.out.println("begin main......");
		try {
			Scanner sc1 = new Scanner(System.in);
			Scanner sc2 = new Scanner(System.in);

			System.out.println("Enter value of x: ");
			int x = sc1.nextInt();

			System.out.println("Enter value of : ");
			int y = sc2.nextInt();

			System.out.println("x=" + x);
			System.out.println("y=" + y);

			int z = x / y;
			System.out.println("z=" + z);
		} catch (InputMismatchException e) {
			System.out.println("Please provide correct input......");
		} catch (ArithmeticException e) {
			System.out.println("Cannot divide by 0");
		}
		System.out.println("--------------------End main----------------------");

	}
}
