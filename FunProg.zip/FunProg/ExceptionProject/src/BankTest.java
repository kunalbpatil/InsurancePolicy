import BankException.IncomeTaxException;
import BankException.InsufficientBalanceException;
import BankException.InvalidAccountHolderNameException;
import BankException.NegativeBalanceException;
import BankException.OpeningBalanceException;

public class BankTest {

	public static void main(String[] args) {
		
		BankAcount bankObj=null;
		
		try {
		bankObj = new BankAcount(1,"Jack",55000);
		System.out.println(bankObj);		
		bankObj.deposit(40000);
		System.out.println(bankObj);
		}
		catch (Exception e) {
			System.out.println("Some problem occured "+e);
		}
		
		bankObj.withdraw(5000);
		System.out.println(bankObj);
	}

}

class BankAcount{
	private int accountNumber;
	private String accountHolder;
	private double accountBalance;
	public BankAcount(int accountNumber, String accountHolder, double accountBalance) throws OpeningBalanceException, InvalidAccountHolderNameException, NegativeBalanceException {
		super();
		this.accountNumber = accountNumber;
		this.accountHolder = accountHolder;
		if (!((!accountHolder.equals(""))
	            && (accountHolder != null)
	            && (accountHolder.matches("^[a-zA-Z ]*$")))) {
			throw new InvalidAccountHolderNameException("Name is not valid");
		}
		else if(accountBalance<0)
		{
			throw new NegativeBalanceException("Balance can't be nagative ");
		}
		else if(accountBalance<2000)
		{
			throw new OpeningBalanceException("Balance should be >=2000");
		}
		this.accountBalance = accountBalance;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	
	void withdraw(double amountToWithdraw) {
		System.out.println("Withdrawing amount: "+amountToWithdraw);
		if(accountBalance<amountToWithdraw) {
			InsufficientBalanceException e = new InsufficientBalanceException("Balence is low");
			throw e;
		}
		accountBalance = accountBalance - amountToWithdraw;
	}
	void deposit(double amountToDeposit) {
		System.out.println("Depositing Amount: "+amountToDeposit);
		accountBalance= accountBalance+ amountToDeposit;
		if(amountToDeposit>50000) {
			IncomeTaxException ie = new IncomeTaxException("Income Tax will be Deducted");
			throw ie;
		}
	}
	public String toString() {
		return "BankAcount [accountNumber=" + accountNumber + ", accountHolder=" + accountHolder + ", accountBalance="
				+ accountBalance + "]";
	}
}