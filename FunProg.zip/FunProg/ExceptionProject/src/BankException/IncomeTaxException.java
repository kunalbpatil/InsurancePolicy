package BankException;

public class IncomeTaxException extends RuntimeException {
	public IncomeTaxException(String msg) {
		super(msg);
	}

}
