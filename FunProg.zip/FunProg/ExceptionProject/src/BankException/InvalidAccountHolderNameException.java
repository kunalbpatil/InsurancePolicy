package BankException;

public class InvalidAccountHolderNameException extends Exception {
	public InvalidAccountHolderNameException(String msg) {
		super(msg);
	}
}
