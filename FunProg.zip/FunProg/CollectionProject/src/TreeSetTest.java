import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetTest {
	public static void main(String[] args) {
		
		ChemicalElement element1 = new ChemicalElement(79, 167.71f, "Gold", "Au");
		ChemicalElement element2 = new ChemicalElement(49, 107.82f, "Silver", "Ag");
		ChemicalElement element3 = new ChemicalElement(29, 63.54f, "Copper", "Cu");
		ChemicalElement element4 = new ChemicalElement(78, 195.08f, "Platinum", "Pt");
		
		TreeSet<ChemicalElement> element = new TreeSet<ChemicalElement>();
		
		System.out.println("Trying to add elemnt..........");
		
		System.out.println("Adding first element..........");
		element.add(element1);
		System.out.println("Adding second element..........");
		element.add(element2);
		System.out.println("Adding Third element..........");
		element.add(element3);
		System.out.println("Adding fourth element..........");
		element.add(element4);
		
		Iterator<ChemicalElement> elementIterator= element.iterator();
		while(elementIterator.hasNext()) {
			ChemicalElement elementPrint = elementIterator.next();
			System.out.println("Element is:"+elementPrint);
		}
		
	}
}

class ChemicalElement implements Comparable<ChemicalElement>{
	int atomicNumber;
	float atomicWeight;
	String atomicName;
	String atomicFormula;
	public ChemicalElement(int atomicNumber, float atomicWeight, String atomicName, String atomicFormula) {
		super();
		this.atomicNumber = atomicNumber;
		this.atomicWeight = atomicWeight;
		this.atomicName = atomicName;
		this.atomicFormula = atomicFormula;
	}
	@Override
	public String toString() {
		return "ChemicalElement [atomicNumber=" + atomicNumber + ", atomicWeight=" + atomicWeight + ", atomicName="
				+ atomicName + ", atomicFormula=" + atomicFormula + "]";
	}
/*	@Override
	public int compareTo(ChemicalElement o) {
		System.out.println("Comparing "+o.atomicNumber+" with "+atomicNumber);
		return Integer.compare(atomicNumber, o.atomicNumber);
		
	}*/
	public int compareTo(ChemicalElement o) {
		System.out.println("Comparing "+o.atomicNumber+" with "+atomicNumber);
		return atomicName.compareTo(o.atomicName);
		
	}
}