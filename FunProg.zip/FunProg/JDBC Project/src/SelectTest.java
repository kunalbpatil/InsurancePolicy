import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SelectTest {
public static void main(String[] args) {
	try {
		System.out.println("Trying to load the driver:");
		DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		System.out.println("Loaded the Driver");
		
		System.out.println("Trying to connect to DB........");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@localhost:1521:xe","system","sysgitc");
		System.out.println("Connected to db......"+ con);
		
		System.out.println("Trying to create statement");
		Statement statement = con.createStatement();
				
		System.out.println("Statement created"+ statement);
		
		ResultSet result = statement.executeQuery("select * from customer");
		System.out.println("Result is:" + result);
		System.out.println("****");
		
		System.out.print("ID\t");
		System.out.print("Name\t\t\t");
		System.out.print("Location");
		System.out.print("\n");
		System.out.println("--------------------------------------------");
		
		while (result.next()) {
			int deptNumber = result.getInt(1);
		    String deptName = result.getString(2);
		    String location = result.getString(3);
		    
		    System.out.print(deptNumber+"\t");
		    System.out.print(deptName+"\t\t");
		    System.out.print(location);
		    System.out.print("\n");
			
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
}
