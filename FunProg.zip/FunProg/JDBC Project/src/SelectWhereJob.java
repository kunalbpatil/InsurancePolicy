
import java.sql.Statement;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SelectWhereJob {
	public static void main(String[] args) {
		try {
			System.out.println("Trying to load the driver:");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Loaded the Driver");

			System.out.println("Trying to connect to DB........");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:" + "@localhost:1521:xe", "system",
					"sysgitc");
			System.out.println("Connected to db......" + con);

			System.out.println("Trying to create statement");
			Statement statement = con.createStatement();

			System.out.println("Statement created" + statement);

			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Emp Job");
			String job = sc.next();

			ResultSet result = statement.executeQuery("select * from emp where job='"+job+"'");
			System.out.println("Result is:" + result);
			System.out.println("****");

			System.out.print("ID\t");
			System.out.print("Name\t\t\t");
			System.out.print("Location");
			System.out.print("\n");
			System.out.println("--------------------------------------------");

			if (result != null) {
				while (result.next()) {
					int empNumber = result.getInt(1);
					String empName = result.getString(2);
					String empJob = result.getString(3);

					System.out.print(empNumber + "\t");
					System.out.print(empName + "\t\t");
					System.out.print(empJob);
					System.out.print("\n");

				}
			} else {
				throw new EmployeeNotFoundException("Employee Not Found");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
