package dao;

import java.util.List;

public interface EmployeeDao {
	//CRUD
	void 	       createEmployee(Employee empObj) throws EmployeeAlreadyPresent;
	Employee 	   readEmployee(int empNumber) throws EmployeeNotFoundException;
	List<Employee> readAllEmployee() throws EmptyTableException;
	void           UpdateEmployee(Employee empObj);
	void           deleteEmployee(int empNumber);
}
