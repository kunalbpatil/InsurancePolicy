package dao;

import java.sql.Date;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class TestDao {
	public static void main(String[] args) throws EmptyTableException {
		EmployeeDaoImpl empDAO = new EmployeeDaoImpl();
		
//		try
//		{
		//	Employee empObj = empDAO.readEmployee(1234);------------for reading 1 employee
//			System.out.println("EMPNO   : "+empObj.getEmployeeNumber());				
//			System.out.println("ENAME   : "+empObj.getEmployeeName());				
//			System.out.println("JOB     : "+empObj.getJob());
//			System.out.println("DOJ     : "+empObj.getEmployeeHieringDate());
//			
//			System.out.println("MANAGER : "+empObj.getEmployeeManagerCode());				
//			System.out.println("SALARY  : "+empObj.getBasicSalary());				
//			System.out.println("COMM    : "+empObj.getCommission());
//			System.out.println("DEPTNO  : "+empObj.getDepartmentNumber());
			
//			List<Employee> empObj1 = empDAO.readAllEmployee();--------for viewing all employee
//		    Iterator<Employee> empIter= empObj1.iterator(); 
//		    while(empIter.hasNext()) {
//				Employee empObj = empIter.next();
//				System.out.println("EMPNO   : "+empObj.getEmployeeNumber());				
//				System.out.println("ENAME   : "+empObj.getEmployeeName());				
//				System.out.println("JOB     : "+empObj.getJob());
//				System.out.println("DOJ     : "+empObj.getEmployeeHieringDate());
//				
//				System.out.println("MANAGER : "+empObj.getEmployeeManagerCode());				
//				System.out.println("SALARY  : "+empObj.getBasicSalary());				
//				System.out.println("COMM    : "+empObj.getCommission());
//				System.out.println("DEPTNO  : "+empObj.getDepartmentNumber());
//				System.out.println("----------------------------------------------------");
//				
//			}
//		}
//		catch(EmployeeNotFoundException e) {
//			System.out.println("Problem : "+e);
//		}
			
//		EmployeeDaoImpl empDelete = new EmployeeDaoImpl();-----------for deleting
//		empDelete.deleteEmployee(1234);
		
		EmployeeDaoImpl empUpdate = new EmployeeDaoImpl();
		Employee emp = new Employee();
		
		Scanner scan1 = new Scanner(System.in);
		Scanner scan2 = new Scanner(System.in);
		Scanner scan3 = new Scanner(System.in);
		Scanner scan4 = new Scanner(System.in);
		Scanner scan5 = new Scanner(System.in);
		Scanner scan6 = new Scanner(System.in);
		Scanner scan7 = new Scanner(System.in);
		Scanner scan8 = new Scanner(System.in);
		
		System.out.println("Enter new emp number to modify : " );
		int empNumber = scan1.nextInt();
		emp.setEmployeeNumber(empNumber);
		if(!empUpdate.isCheck(empNumber)){
			throw new EmployeeNotFoundException("Employee is not present with empno="+empNumber); 
		}
		
		System.out.println("Enter modified emp name   : " );
		String empName = scan2.nextLine();	
		emp.setEmployeeName(empName);
		
		System.out.println("Enter modified emp job    : " );
		String empJob = scan3.nextLine();
		emp.setJob(empJob);
		
		System.out.println("Enter modified emp manager: " );
		int managerCode= scan4.nextInt();	
		emp.setEmployeeManagerCode(managerCode);
		
		System.out.println("Enter modified emp joining: " );
		String str = scan5.next();
		java.sql.Date doj = Date.valueOf(str);
		emp.setEmployeeHieringDate(doj);
		
		System.out.println("Enter modified emp salary : " );
		double empSalary = scan6.nextDouble();		
		emp.setBasicSalary(empSalary);
		
		System.out.println("Enter modified emp comm   : " );
		double empComm= scan7.nextDouble();
		emp.setCommission(empComm);
		
		System.out.println("Enter modified dept num   : " );
		int deptNumber = scan8.nextInt();
		emp.setDepartmentNumber(deptNumber);
		
		empUpdate.UpdateEmployee(emp);

		empDAO.closeDBResources();
	}
}