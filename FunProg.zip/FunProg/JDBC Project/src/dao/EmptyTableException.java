package dao;

public class EmptyTableException extends Exception {
	public EmptyTableException(String msg) {
		super(msg);
	}
}
