package dao;

public class EmployeeAlreadyPresent extends RuntimeException {
	public EmployeeAlreadyPresent(String msg) {
		super(msg);
	}

}
