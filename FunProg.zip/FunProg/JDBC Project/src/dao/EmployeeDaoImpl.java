package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EmployeeDaoImpl implements EmployeeDao {
	Connection conn;
	public void closeDBResources() {
		try {
			conn.close();
			System.out.println("DB connection is closed....");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public EmployeeDaoImpl() {
		try {
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Loaded the driver.....");
			
			System.out.println("Trying to connect to the DB...");
			conn = DriverManager.getConnection("jdbc:oracle:thin:"
					+ "@localhost:1521:xe",
					"system", "sysgitc");
			System.out.println("connected to the db...."+conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void createEmployee(Employee empObj) throws EmployeeAlreadyPresent {
		try {
			PreparedStatement pst = conn.prepareStatement("insert into emp values (?,?,?,?,?,?,?,?)");
			
			Statement statement = conn.createStatement();
			ResultSet rs = statement.executeQuery("select * from emp where empno="+empObj.getEmployeeNumber());
			if(rs.next()) {
				EmployeeAlreadyPresent ex = new EmployeeAlreadyPresent("Employee number already present : "+empObj.getEmployeeNumber());
				throw ex;
			}
			
			//hint : run the select query with Statement interface
			// to find if employee exists - if (rs.next()) 
			// if found, EmployeeAlreayExistsException thrown...Checked Exception
			
			
			pst.setString(1, empObj.getEmployeeName()); 
			pst.setString(2, empObj.getJob());
			pst.setInt(3, empObj.getEmployeeManagerCode());
			pst.setDate(4, (Date) empObj.getEmployeeHieringDate() );
			pst.setDouble(5, empObj.getBasicSalary() );
			pst.setDouble(6, empObj.getCommission() );
			pst.setInt(7, empObj.getDepartmentNumber() );
			
			pst.setInt(8, empObj.getDepartmentNumber() );
			
			int rowsInserted = pst.executeUpdate();
			System.out.println("Statement executed : rows created : "+rowsInserted);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public Employee readEmployee(int empNumber) throws EmployeeNotFoundException {
Employee empObj = null;
		
		try {
			System.out.println("Trying to create statement...");
			Statement statement = conn.createStatement();
			System.out.println("Statement created : "+statement);
			
			System.out.println("Trying to execute statement...");
			ResultSet resultSet = statement.executeQuery("SELECT * FROM emp where empno="+empNumber);
			
			System.out.println("Statement executed : got the result : "+resultSet);
			
			if(resultSet.next()) {
				empObj = new Employee(); //create a blank employee object
				
				//and fill it up if record is there
				empObj.setEmployeeNumber(resultSet.getInt(1));
				empObj.setEmployeeName(resultSet.getString(2));
				empObj.setJob(resultSet.getString(3));
				empObj.setEmployeeManagerCode(resultSet.getInt(4));
				empObj.setEmployeeHieringDate(resultSet.getDate(5));
				empObj.setBasicSalary(resultSet.getDouble(6));
				empObj.setCommission(resultSet.getDouble(7));
				empObj.setDepartmentNumber(resultSet.getInt(8));
			}
			else {
				throw new EmployeeNotFoundException("Employee Number does not exits : "+empNumber);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empObj;
	}

	@Override
	public List<Employee> readAllEmployee() throws EmptyTableException {
		List<Employee> empList = new ArrayList<Employee>();
		try {
			Statement st = conn.createStatement();
			
			ResultSet resultSet=st.executeQuery("select * from emp");
			
			while(resultSet.next()) {
				Employee empObj = new Employee();
				empObj.setEmployeeNumber(resultSet.getInt(1));
				empObj.setEmployeeName(resultSet.getString(2));
				empObj.setJob(resultSet.getString(3));
				empObj.setEmployeeManagerCode(resultSet.getInt(4));
				empObj.setEmployeeHieringDate(resultSet.getDate(5));
				empObj.setBasicSalary(resultSet.getDouble(6));
				empObj.setCommission(resultSet.getDouble(7));
				empObj.setDepartmentNumber(resultSet.getInt(8));
				empList.add(empObj);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empList;
	}

	@Override
	public void UpdateEmployee(Employee empObj) {
		try {
			PreparedStatement pst = conn.prepareStatement("UPDATE emp set ename=?,job=?,mgr=?,hiredate=?,sal=?,comm=?,deptno=? where empno=?");
			pst.setString(1, empObj.getEmployeeName()); 
			pst.setString(2, empObj.getJob());
			pst.setInt(3, empObj.getEmployeeManagerCode());
			pst.setDate(4, (Date) empObj.getEmployeeHieringDate() );
			pst.setDouble(5, empObj.getBasicSalary() );
			pst.setDouble(6, empObj.getCommission() );
			pst.setInt(7, empObj.getDepartmentNumber() );
			
			pst.setInt(8, empObj.getEmployeeNumber() );
			System.out.println("prepared statement is created..."+pst);
			int row = pst.executeUpdate();
			System.out.println("row UPDATED..."+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	@Override
	public void deleteEmployee(int empNumber) {
		try {
			PreparedStatement pst = conn.prepareStatement("delete from emp where empno=?");
			Statement statement = conn.createStatement();
			ResultSet rs = statement.executeQuery("select * from emp where empno="+empNumber);
			
			if(rs.next()) {
				pst.setInt(1, empNumber );
				int rowsDeleted = pst.executeUpdate();
				System.out.println("Statement executed : rows deleted : "+rowsDeleted);
			}
			else {
				EmployeeNotFoundException ex = new EmployeeNotFoundException("Employee not found : "+empNumber);
				throw ex;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public boolean isCheck(int empNumber) {
		boolean b=false;
		try {
			Statement statement = conn.createStatement();
			
			ResultSet result = statement.executeQuery("select empno from emp where empno="+empNumber);
			if(result.next()) {
				b=true;

			}
			else {
				throw new EmployeeNotFoundException("Employee Id Does not exists");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
		
}
}
