//import java.sql.Statement;
//import java.util.Scanner;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//public class DeleteTest {
//public static void main(String[] args) {
//		try {
//			System.out.println("Trying to load the driver:");
//			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
//			System.out.println("Loaded the Driver");
//			
//			System.out.println("Trying to connect to DB........");
//			Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@localhost:1521:xe","system","sysgitc");
//			System.out.println("Connected to db......"+ con);
//			
//			System.out.println("Trying to create statement");
//			Statement statement = con.createStatement();
//					
//			System.out.println("Statement created"+ statement);
//			
//			Scanner sc = new Scanner(System.in);
//			System.out.println("Enter employee number to be deleted:");
//			int empNo = sc.nextInt();
//			
//			ResultSet rs = statement.executeQuery("select empno from emp where empno='"+empNo+"'");
//			if(rs.next()) {
//				statement.executeQuery("delete from emp where empno="+empNo);
//				System.out.println("Deleted successfully");	
//			}
//			else {
//				throw new EmployeeNotFoundException("Employee does not exist");
//}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//}
//}



import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteTest {
	public static void main(String[] args) {
		
		try {
			//1. load the driver...
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Loaded the driver.....");
			
			System.out.println("Trying to connect to the DB...");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:"
					+ "@localhost:1521:xe",
					"system", "sysgitc");
			System.out.println("connected to the db...."+conn);
			
			System.out.println("Trying to create PreparedStatement...");
			PreparedStatement pst = conn.prepareStatement("delete from emp where empno=?");
			System.out.println("PreparedStatement created : "+pst);
			
			System.out.println("Trying to execute statement...");
			Scanner scan1 = new Scanner(System.in);
			
			System.out.println("Enter new emp number delete : " );
			int empNumber = scan1.nextInt();
			
			Statement statement = conn.createStatement();
			ResultSet rs = statement.executeQuery("select * from emp where empno="+empNumber);
			
			if(rs.next()) {
				pst.setInt(1, empNumber );
				int rowsDeleted = pst.executeUpdate();
				System.out.println("Statement executed : rows deleted : "+rowsDeleted);
			}
			else {
				EmployeeNotFoundException ex = new EmployeeNotFoundException("Employee not found : "+empNumber);
				throw ex;
			}
			
			pst.close();			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
