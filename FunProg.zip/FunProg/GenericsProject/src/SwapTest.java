
public class SwapTest {
	public static void main(String[] args) {
		IntegerPair ip = new IntegerPair(10, 20);
		ip.print();
		ip.swap();
		ip.print();
		
	}
}

class IntegerPair {
	int x;
	int y;

	public IntegerPair(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}

	void print() {
		System.out.println("x=: " + x);
		System.out.println("y=: " + y);
	}

	void swap() {
		System.out.println("Swapping.....");
		int temp = x;
		x = y;
		y = temp;
		System.out.println("Swapped....");
	}
}
