import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;

//inTention + atTention

/*
 * ARRAY
 * 	group of variables/references
 * 	of same type
 *  stored in consecutive memory
 *  referred by a common name
 *  CANNOT GROW OR SHRINK
 *  
 * COLLECTION
 * 	group of variables/references
 *  of same/diff type
 *  stored in consecutive memory
 *  referred by a common name
 *  CAN GROW OR SHRINK
 */
public class GenericTest {
	public static void main(String[] args) {

		Log log1 = new Log(1, "Error at line 40", "Database Error", LocalDateTime.now());
		Log log2 = new Log(1, "Error at line 140", "Null Point Error", LocalDateTime.now());
		Log log3 = new Log(1, "Error at line 180", "Wrong Value Error", LocalDateTime.now());

		ArrayList<Log> log = new ArrayList<Log>();
		System.out.println("Log is created using Array List..... ");

		System.out.println("Adding Log1 ");
		log.add(log1);

		System.out.println("Adding Log2 ");
		log.add(log2);

		System.out.println("Adding Log3 ");
		log.add(log3);

		Iterator<Log> logIter = log.iterator();
		while (logIter.hasNext()) {
			Log logPrint = logIter.next();
			System.out.println("The Log : " + logPrint);
		}
		System.out.println("---------------------------");

		Contact contact1 = new Contact("Raj", "raj@gmail.com", "RajSri", 7812453641L);
		Contact contact2 = new Contact("Ajay", "ajy@gmail.com", "AjayS", 9621453478L);
		Contact contact3 = new Contact("Jay", "jay@gmail.com", "JaySri", 8512364794L);

		LinkedList<Contact> contact = new LinkedList<Contact>();
		System.out.println("Contact is created using Linked List....");

		System.out.println("Adding Contact1 ");
		contact.add(contact1);

		System.out.println("Adding Contact2 ");
		contact.add(contact2);

		System.out.println("Adding Contact3 ");
		contact.add(contact3);

		Iterator<Contact> contactIter = contact.iterator();
		while (contactIter.hasNext()) {
			Contact contactPrint = contactIter.next();
			System.out.println("The Log : " + contactPrint);
		}
		System.out.println("---------------------------");

		ChemicalElement element1 = new ChemicalElement(3,7,"Li@2","Lithium");
		ChemicalElement element2 = new ChemicalElement(3,7,"Li@2","Lithium");
		ChemicalElement element3 = new ChemicalElement(3,7,"Li@2","Lithium");

		HashSet<ChemicalElement> element = new HashSet<ChemicalElement>();
		System.out.println("Element is created using Hash Set....");

		System.out.println("Adding Element1 ");
		element.add(element1);

		System.out.println("Adding Contact2 ");
		element.add(element2);

		System.out.println("Adding Contact3 ");
		element.add(element3);

		Iterator<ChemicalElement> elementIter = element.iterator();
		while (elementIter.hasNext()) {
			ChemicalElement elementPrint = elementIter.next();
			System.out.println("The Log : " + elementPrint);
		}
		System.out.println("---------------------------");

		Book book1 = new Book(4,480,"ABC","ABC123","James",595);
		Book book2 = new Book(4,480,"ABC","ABC123","James",595);
		Book book3 = new Book(4,480,"ABC","ABC123","James",595);

		TreeSet<Book> book = new TreeSet<Book>();
		System.out.println("Book is created using Hash Set....");

		System.out.println("Adding Book1 ");
		book.add(book1);

		System.out.println("Adding Book2 ");
		book.add(book2);

		System.out.println("Adding Book3 ");
		book.add(book3);

		Iterator<Book> bookIter = book.iterator();
		while (bookIter.hasNext()) {
			Book bookPrint = bookIter.next();
			System.out.println("The Log : " + bookPrint);
		}

	}
}

class Log {
	int logLevel;
	String logMsg;
	String logType;
	LocalDateTime logDateTime;

	public Log(int logLevel, String logMsg, String logType, LocalDateTime logDateTime) {
		super();
		this.logLevel = logLevel;
		this.logMsg = logMsg;
		this.logType = logType;
		this.logDateTime = logDateTime;
	}

	@Override
	public String toString() {
		return "Log [logLevel=" + logLevel + ", logMsg=" + logMsg + ", logType=" + logType + ", logDateTime="
				+ logDateTime + "]";
	}
}

class Contact {
	String name;
	String email, facebookID;
	long mobileNember;

	public Contact(String name, String email, String facebookID, long mobileNember) {
		super();
		this.name = name;
		this.email = email;
		this.facebookID = facebookID;
		this.mobileNember = mobileNember;
	}

	@Override
	public String toString() {
		return "Contact [name=" + name + ", email=" + email + ", facebookID=" + facebookID + ", mobileNember="
				+ mobileNember + "]";
	}
}

class ChemicalElement {
	int atomicNumer, atomicWeight;
	String atomicFormula, atomicName;

	public ChemicalElement(int atomicNumer, int atomicWeight, String atomicFormula, String atomicName) {
		super();
		this.atomicNumer = atomicNumer;
		this.atomicWeight = atomicWeight;
		this.atomicFormula = atomicFormula;
		this.atomicName = atomicName;
	}

	@Override
	public String toString() {
		return "ChemicalElement [atomicNumer=" + atomicNumer + ", atomicWeight=" + atomicWeight + ", atomicFormula="
				+ atomicFormula + ", atomicName=" + atomicName + "]";
	}
}

class Book implements Comparable<Book>{
	int bookID, numberOfPages;
	String bookTitle, bookEdition, bookAuthor;
	double bookPrice;

	public Book(int bookID, int numberOfPages, String bookTitle, String bookEdition, String bookAuthor,
			double bookPrice) {
		super();
		this.bookID = bookID;
		this.numberOfPages = numberOfPages;
		this.bookTitle = bookTitle;
		this.bookEdition = bookEdition;
		this.bookAuthor = bookAuthor;
		this.bookPrice = bookPrice;
	}

	@Override
	public String toString() {
		return "Book [bookID=" + bookID + ", numberOfPages=" + numberOfPages + ", bookTitle=" + bookTitle
				+ ", bookEdition=" + bookEdition + ", bookAuthor=" + bookAuthor + ", bookPrice=" + bookPrice + "]";
	}

	@Override
	public int compareTo(Book o) {
		return Integer.compare(bookID, o.bookID);
	}

}