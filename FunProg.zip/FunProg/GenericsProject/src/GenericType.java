
public class GenericType {
	public static void main(String[] args) {

		AnyPair<Integer> pair = new AnyPair<Integer>(10, 30);
		pair.print();
		pair.swap();
		pair.print();
		
		
		
		AnyPair<Float> pair2 = new AnyPair<Float>(15.2f, 18.5f);
		pair2.print();
		pair2.swap();
		pair2.print();
		
		System.out.println("----------------------------");
		
		Song s1 = new Song("Tere Bin", "Jal", "Atif", 2002);
		Song s2 = new Song("Awara", "Agni", "Sanam", 2018);
		AnyPair<Song> pair3 = new AnyPair<Song>(s1,s2);
		pair3.print();
		pair3.swap();
		pair3.print();
	}
}

class AnyPair<T> {
	T x;
	T y;

	public AnyPair(T x, T y) {
		super();
		this.x = x;
		this.y = y;
	}

	void print() {
		System.out.println("x=: " + x);
		System.out.println("y=: " + y);
	}

	void swap() {
		System.out.println("Swapping.....");
		T temp = x;
		x = y;
		y = temp;
		System.out.println("Swapped....");
	}
}