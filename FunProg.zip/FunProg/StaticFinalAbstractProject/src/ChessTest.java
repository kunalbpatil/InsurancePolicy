
public class ChessTest {
	public static void main(String[] args) {
		Chess ch = new GraphicalChess();
		ch.moveBishop();

	}
}

class Chess {
	final int TOTAL_SQUARE = 64;

	void moveBishop() {
		System.out.println("Bishop move cross driection...");
	}

	final void moveQueen() {
		System.out.println("Queen m ove in all direction");
	}
}

class GraphicalChess extends Chess {
	void moveBishop() {
		System.out.println("Grapgically move in cross direction");
	}
}