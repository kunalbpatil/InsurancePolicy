
public class CircleTest {
	public static void main(String[] args) {
		Circle c = new Circle(5.0);
		c.calculateArea();
	}
}
class Circle{
	final double PI=3.14;
	double radius;
	public Circle(double radius) {
		super();
		this.radius = radius;
	}
	void calculateArea() {
		double area = PI*radius*radius;
		System.out.println("Area:+ "+ area);
		
	}
}
