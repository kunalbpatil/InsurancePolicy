
public class InterfaceTest {

	public static void main(String[] args) {
		
	}

}
