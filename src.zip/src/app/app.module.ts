import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { SimpleInterestCalculatorComponent } from './simple-interest-calculator/simple-interest-calculator.component';
import { FormsModule } from '@angular/forms';
import { CurrencyConverterComponent } from './currency-converter/currency-converter.component';
import { LoginLogoutComponent } from './login-logout/login-logout.component';
import {MatSliderModule} from '@angular/material/slider';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CubePipe } from './cube.pipe';
import { PNRPipe } from './pnr.pipe';
import { PayeeModule } from './payee/payee.module';
import { TransferModule } from './transfer/transfer.module';
import { StatementModule } from './statement/statement.module';
import { UserDetailsComponent } from './user-details/user-details.component';
import {HttpClientModule} from '@angular/common/http';
import { PhotoDetailsComponent } from './photo-details/photo-details.component';
@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    SimpleInterestCalculatorComponent,
    CurrencyConverterComponent,
    LoginLogoutComponent,
    CubePipe,
    PNRPipe,
    UserDetailsComponent,
    PhotoDetailsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    MatSliderModule,
    PayeeModule,
    StatementModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
