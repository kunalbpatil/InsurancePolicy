import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {
  photoNumber!:number;
  baseURL ='https://jsonplaceholder.typicode.com/photos';
  

  constructor(private myhttp : HttpClient) { }

  findAllPhotos():Observable<any[]>{
    return this.myhttp.get<any[]>(this.baseURL);
  }

  findPhto(photoNumber:number):Observable<any>{
    let baseURL2  = 'https://jsonplaceholder.typicode.com/photos/'+photoNumber;
    return this.myhttp.get<any>(baseURL2);
  }


}
