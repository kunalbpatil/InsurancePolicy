import { Component, OnInit } from '@angular/core';
import { CalculatorService } from 'src/app/calculator.service';

@Component({
  selector: 'app-add-payee',
  templateUrl: './add-payee.component.html',
  styleUrls: ['./add-payee.component.css']
})
export class AddPayeeComponent implements OnInit {
  sum!:number;
  x!:number;
  y!:number;
  constructor() { }

  calcsvc:CalculatorService = new CalculatorService();
  ngOnInit(): void {
  }
  makeSumOfTwoNumbers(){
    this.sum = this.calcsvc.addTwoNumbersService(this.x,this.y);
  }
}
