import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modify-payee-limit',
  templateUrl: './modify-payee-limit.component.html',
  styleUrls: ['./modify-payee-limit.component.css']
})
export class ModifyPayeeLimitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
