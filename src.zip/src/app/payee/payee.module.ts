import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddPayeeComponent } from './add-payee/add-payee.component';
import { DeletePayeeComponent } from './delete-payee/delete-payee.component';
import { ViewPayeeComponent } from './view-payee/view-payee.component';
import { ViewAllPayeeComponent } from './view-all-payee/view-all-payee.component';
import { ModifyPayeeLimitComponent } from './modify-payee-limit/modify-payee-limit.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    AddPayeeComponent,
    DeletePayeeComponent,
    ViewPayeeComponent,
    ViewAllPayeeComponent,
    ModifyPayeeLimitComponent
  ],
  exports:[
    AddPayeeComponent,
    DeletePayeeComponent,
    ViewAllPayeeComponent,
    ViewPayeeComponent,
    ModifyPayeeLimitComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ]
})
export class PayeeModule { }
