import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor() {
    console.log('RegisterComponent constructor invoked... ');
   }

  ngOnInit(): void {
    console.log('RegisterComponent ngOnInit() invoked... ');
  }

}
