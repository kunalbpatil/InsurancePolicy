import { Component, OnInit } from '@angular/core';
import { CurrencyConverterService } from '../currency-converter.service';

@Component({
  selector: 'app-currency-converter',
  templateUrl: './currency-converter.component.html',
  styleUrls: ['./currency-converter.component.css']
})
export class CurrencyConverterComponent implements OnInit {
  srcCurrency!:string;
  srcAmount!:number;
  targetCurrency!:string;
  targetAmount!:number;


  constructor(private convertSvc:CurrencyConverterService) { }

  ngOnInit(): void {
  }

  formatLabel(value: number) {
    if (value >= 1000) {
      return Math.round(value / 1000) + 'k';
    }

    return value;
  }

  convert(){
    this.targetAmount = this.convertSvc.convertCurrency(this.srcCurrency,this.srcAmount,this.targetCurrency)
  }

}
