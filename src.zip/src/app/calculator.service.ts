import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculatorService {

  constructor() { }

  addTwoNumbersService(x:number,y:number):number{
    return x+y;
  }

  subtractTwoNumbersService(x:number,y:number):number{
    return x-y;
  }
  multiplyTwoNumbersService(x:number,y:number):number{
    return x*y;
  }
  divideTwoNumbersService(x:number,y:number):number{
    return x/y;
  }
}
