import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simple-interest-calculator',
  templateUrl: './simple-interest-calculator.component.html',
  styleUrls: ['./simple-interest-calculator.component.css']
})
export class SimpleInterestCalculatorComponent implements OnInit {
  principal!:number;
  numberOfYears!:number;
  rateOfInterest!:number;
  simpleInterest:number = this.principal*this.rateOfInterest*this.numberOfYears/100;
  

  constructor() {  }

  ngOnInit(): void {
  }

  calculateSI():void {
    console.log('Calculating SI....');
    this.simpleInterest = this.principal*this.rateOfInterest*this.numberOfYears/100;
  }

}
