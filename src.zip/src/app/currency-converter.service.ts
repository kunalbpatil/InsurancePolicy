import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CurrencyConverterService {

  constructor() { }
  convertCurrency(srcCurrency:string,srcAmount:number,targetCurrency:string):number{
    
    switch(srcCurrency){
      case 'INR' :
        switch(targetCurrency){
          case 'USD':
            return srcAmount * 0.013;
            break;
          case 'EUR':
              return srcAmount * 0.012;
              break;
          case 'JPY':
                return srcAmount * 1.72;
                break;
        }
        break;

      case 'USD' :
          switch(targetCurrency){
            case 'INR':
              return srcAmount * 78.02;
              break;
            case 'EUR':
                return srcAmount * 0.96;
                break;
            case 'JPY':
                  return srcAmount * 134.29;
                  break;
          }
          break;
      case 'EUR' :
          switch(targetCurrency){
            case 'INR':
              return srcAmount * 81.50;
              break;
            case 'USD':
                return srcAmount * 1.04;
                break;
            case 'JPY':
                  return srcAmount * 140.25;
                  break;
          }
          break;
      case 'JPY' :
            switch(targetCurrency){
              case 'INR':
                return srcAmount * 0.58;
                break;
              case 'USD':
                  return srcAmount * 0.0074;
                  break;
              case 'EUR':
                    return srcAmount * 0.0071;
                    break;
            }
            break;

    }
      return 0;
  }

}
