import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pNR'
})
export class PNRPipe implements PipeTransform {

  transform(principal: number, rate:number,time:number): number {
    return principal * rate*time/100 ;
  }

}
