import { Component, OnInit } from '@angular/core';
import { UserDetailsService } from '../user-details.service';

@Component({
  selector: 'app-photo-details',
  templateUrl: './photo-details.component.html',
  styleUrls: ['./photo-details.component.css']
})
export class PhotoDetailsComponent implements OnInit {

  constructor(private uds:UserDetailsService) { }
  // myPhotos : any[] = [];
  myphoto !:any;
  myphotoNumber !:number;
  ngOnInit(): void {
    // this.uds.findAllPhotos().subscribe({
    //   next : (n) => this.myPhotos = n,
    //   error: (e) => console.log(e),
      
    // });
    
   
  }

  getPhoto(){
    this.uds.findPhto(this.myphotoNumber).subscribe({
      next:(n) => this.myphoto = n,
      error: (e) => alert('Something went wrong...'),
    });
  }


}
