import { Component } from '@angular/core';
import { Employee } from './Employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  employeeNumber : number= 7839;
  empName : string= 'King';
  maritalStatus : boolean = true;
  job :string= 'President';
  managerCode:number = 7755;
  hireDate :Date= new Date('2022-06-04');
  basicSalary : number= 5000;
  commission :number= 800;
  deptNumber :number= 20;

  emp : Employee = new Employee();
  
  empArr : Employee[] = [
    {
      'employeeNumber':1235,
      'empName':'Janet',
      'maritalStatus':true,
      'job':'CLERK',
      'managerCode':7839,
      'hireDate': new Date('2022-06-12'),
      'basicSalary': 7000,
      'commission': 888,
      'deptNumber':20

    },
    {
      'employeeNumber':1236,
      'empName':'June',
      'maritalStatus':false,
      'job':'CLERK',
      'managerCode':7839,
      'hireDate': new Date('2022-06-12'),
      'basicSalary': 7500,
      'commission': 888,
      'deptNumber':10

    },
    {
      'employeeNumber':1237,
      'empName':'Klaus',
      'maritalStatus':true,
      'job':'MANAGER',
      'managerCode':7839,
      'hireDate': new Date('2022-06-12'),
      'basicSalary': 10000,
      'commission': 888,
      'deptNumber':10

    }
  ];

  title = 'Kunal';
  constructor(){
    console.log('AppComponent constructor invoked... ');
    this.emp.employeeNumber = 1234;
    this.emp.empName = 'Abhi';
    this.emp.job = 'Manager';
    this.emp.managerCode = 7839;
    this.emp.hireDate = new Date('2022-06-01');
    this.emp.basicSalary = 9000;
    this.emp.commission =  666;
    this.emp.deptNumber = 10;
    this.emp.maritalStatus = false;

  }
}
