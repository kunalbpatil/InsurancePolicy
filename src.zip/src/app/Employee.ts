export class Employee{
    employeeNumber !: number;
  empName !: string;
  maritalStatus !: boolean;
  job !:string;
  managerCode!:number ;
  hireDate !:Date;
  basicSalary !: number;
  commission !:number;
  deptNumber !:number;

}