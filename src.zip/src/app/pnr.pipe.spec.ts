import { PNRPipe } from './pnr.pipe';

describe('PNRPipe', () => {
  it('create an instance', () => {
    const pipe = new PNRPipe();
    expect(pipe).toBeTruthy();
  });
});
