import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonthlystatementComponent } from './monthlystatement/monthlystatement.component';



@NgModule({
  declarations: [
    MonthlystatementComponent
  ],
  exports:[
    MonthlystatementComponent
  ],
  imports: [
    CommonModule
  ]
})
export class StatementModule { }
