import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-monthlystatement',
  templateUrl: './monthlystatement.component.html',
  styleUrls: ['./monthlystatement.component.css']
})
export class MonthlystatementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
