import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MonthlystatementComponent } from './monthlystatement.component';

describe('MonthlystatementComponent', () => {
  let component: MonthlystatementComponent;
  let fixture: ComponentFixture<MonthlystatementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MonthlystatementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MonthlystatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
