import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-logout',
  templateUrl: './login-logout.component.html',
  styleUrls: ['./login-logout.component.css']
})
export class LoginLogoutComponent implements OnInit {
  loginFlag!:boolean;

  constructor() { }

  ngOnInit(): void {
  }

  setFlag(flagValue: boolean){
    this.loginFlag = flagValue;

  }

}
