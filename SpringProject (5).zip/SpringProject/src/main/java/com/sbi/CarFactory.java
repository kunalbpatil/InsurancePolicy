package com.sbi;

public class CarFactory {

	public Car getCar() {
		/*Piston thePiston = new Piston("TwinSpark");
		Engine theEngine = new Engine(thePiston);
		Car theCar = new Car(theEngine);*/
		return null;
	}
}
