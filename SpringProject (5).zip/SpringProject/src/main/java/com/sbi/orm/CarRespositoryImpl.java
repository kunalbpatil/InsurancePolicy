package com.sbi.orm;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("carRepo")
public class CarRespositoryImpl implements CarRepository{
	@PersistenceContext(name="SpringJPA")
	EntityManager em ;
	public CarRespositoryImpl() {
		// TODO Auto-generated constructor stub
//		EntityManagerFactory emf= Persistence.createEntityManagerFactory("MyJPA");
//		em = emf.createEntityManager();
	}
	@Override
	@Transactional
	public void insertCar(Car car) {
		// TODO Auto-generated method stub
		
		Car carObj = em.find(Car.class, car.getCarId());
		if(carObj == null)
		{
//			em.getTransaction().begin();
			em.persist(car);
//			em.getTransaction().commit();
			System.out.println("Car inserted..");
		}
		else {
			System.out.println("Car already exists..");
		}
		
		
	}

	@Override
	@Transactional
	public void updateCar(Car car) {

		Car carObj = em.find(Car.class, car.getCarId());
		if(carObj == null)
		{
			
			System.out.println("Car not found..");
		}
		else {
			em.merge(car);
			System.out.println("Car is updated..");
		}
		
		
	}

	@Override
	@Transactional
	public void deleteCar(int carId) {
		// TODO Auto-generated method stub
		Car carObj = em.find(Car.class, carId);
		if(carObj == null)
		{
			
			System.out.println("Car not found..");
		}
		else {
			em.remove(carObj);
			System.out.println("Car is deleted..");
		}
	}

	@Override
	public Car selectCar(int carId) {
		// TODO Auto-generated method stub
		Car carObj = em.find(Car.class, carId);
		if(carObj == null)
		{
			
			System.out.println("Car not found..");
		}
		else {
			
			System.out.println("Car found..");
		}
		return carObj;
	}

	@Override
	public List<Car> selectAllCars() {
		// TODO Auto-generated method stub
		TypedQuery<Car> query = em.createQuery("from Car", Car.class);
		List<Car> carList = query.getResultList();
		if(carList == null)
			System.out.println("No car found/ something went wrong...");
		else
			System.out.println("Found cars.."+carList.size());
		return carList;
	}
	
}
