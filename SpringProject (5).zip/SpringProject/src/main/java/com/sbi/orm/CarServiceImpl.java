package com.sbi.orm;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import myexceptions.CarAlreadyExistsException;

@Service
public class CarServiceImpl implements CarService {
	@Autowired
	CarRepository carRepo;
	
	@Override
	public void saveCar(Car car) {
		// TODO Auto-generated method stub
		Car theCar = carRepo.selectCar(car.getCarId());
		if(theCar != null) {
			throw new CarAlreadyExistsException("The Car already exists..");
		}
		else {
			carRepo.insertCar(car);
		}
	}

	@Override
	public void modifyCar(Car car) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCar(int carId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Car selectCar(int carId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Car> selectAllCars() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
