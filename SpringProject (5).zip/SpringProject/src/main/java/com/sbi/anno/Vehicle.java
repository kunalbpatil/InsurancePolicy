package com.sbi.anno;

import org.springframework.stereotype.Component;

@Component
public interface Vehicle {
	public void drive();
}
