import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.orm.Car;
import com.sbi.orm.CarRepository;
import com.sbi.orm.CarService;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = { "classpath:SpringORM.xml" })
public class CarServiceTest {
	@Autowired
	CarService carService;
	
	@Test
	void saveCarTest() {
		Car theCar = new Car();
		theCar.setCarId(30);
		theCar.setCarName("Audi");
		carService.saveCar(theCar);
	}
}
